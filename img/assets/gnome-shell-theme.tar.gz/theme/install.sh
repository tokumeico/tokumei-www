#!/bin/bash
glib-compile-resources gnome-shell-theme.gresource.xml
sudo /usr/share/gnome-shell/gnome-shell-theme.gresource /usr/share/gnome-shell/gnome-shell-theme.gresource.bak
sudo cp gnome-shelltheme.gresource /usr/share/gnome-shell/
echo "Please restart GNOME by pressing ALT-F2, r, Enter"

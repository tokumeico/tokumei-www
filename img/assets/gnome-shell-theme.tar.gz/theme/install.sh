#!/bin/bash

glib-compile-resources gnome-shell-theme.gresource.xml #compile resource
echo "backing up default shell theme to /usr/share/gnome-shell/gnome-shell-theme.gresource.bak"
sudo mv /usr/share/gnome-shell/gnome-shell-theme.gresource /usr/share/gnome-shell/gnome-shell-theme.gresource.bak
echo "copying over new theme"
sudo cp ./gnome-shell-theme.gresource /usr/share/gnome-shell/
echo "Please restart GNOME by pressing ALT-F2, r, Enter"
